#include "student_file.h"
#include "catch.hpp"

TEST_CASE( "Test 02", "Example Project" )
{
  int *arr = new int[10];
  delete arr;
}