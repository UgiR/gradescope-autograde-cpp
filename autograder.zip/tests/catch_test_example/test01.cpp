#include "student_file.h"
#include "catch.hpp"

TEST_CASE( "Test 01", "Example Project" )
{
  int x = 2 + 3;
  REQUIRE(x == 5);
}