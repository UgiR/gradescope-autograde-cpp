#include <vector>

int main() {
	return 0;
}
